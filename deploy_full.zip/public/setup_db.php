<?php
/**
 * Database Setup Script for InfinityFree
 * Access this via: http://arisanku.rf.gd/setup_db.php
 * DELETE THIS FILE AFTER USE!
 */

// Database credentials
$host = 'sql110.infinityfree.com';
$dbname = 'if0_43086073_arisanku';
$username = 'if0_43086073';
$password = 'XdRNePK250k1';

echo "<h2>Database Setup - Arisan PKK KarangKedawung</h2>";
echo "<pre>";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    echo "✓ Connected to database successfully!\n\n";

    // Read SQL file
    $sqlFile = __DIR__ . '/database_infinityfree.sql';
    if (!file_exists($sqlFile)) {
        // Try parent directory (if we're in public/)
        $sqlFile = __DIR__ . '/../database_infinityfree.sql';
    }
    
    if (!file_exists($sqlFile)) {
        die("✗ SQL file not found! Please upload database_infinityfree.sql\n");
    }

    $sql = file_get_contents($sqlFile);
    echo "✓ SQL file loaded (" . strlen($sql) . " bytes)\n\n";

    // Split SQL by semicolon (but not inside strings)
    $pdo->exec("SET FOREIGN_KEY_CHECKS=0");
    $pdo->exec("SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO'");
    
    // Execute statements one by one
    $statements = array_filter(array_map('trim', explode(";\n", $sql)));
    $executed = 0;
    $errors = 0;
    
    foreach ($statements as $stmt) {
        $stmt = trim($stmt);
        if (empty($stmt) || $stmt === 'COMMIT' || strpos($stmt, 'SET ') === 0 || strpos($stmt, 'START TRANSACTION') === 0) {
            continue;
        }
        
        try {
            $pdo->exec($stmt);
            $executed++;
            
            // Show progress for CREATE TABLE and INSERT
            if (strpos($stmt, 'CREATE TABLE') !== false) {
                preg_match('/CREATE TABLE.*?`(\w+)`/', $stmt, $m);
                echo "✓ Created table: " . ($m[1] ?? 'unknown') . "\n";
            } elseif (strpos($stmt, 'INSERT INTO') !== false) {
                preg_match('/INSERT INTO `(\w+)`/', $stmt, $m);
                echo "✓ Inserted data into: " . ($m[1] ?? 'unknown') . "\n";
            } elseif (strpos($stmt, 'DROP TABLE') !== false) {
                preg_match('/DROP TABLE.*?`(\w+)`/', $stmt, $m);
                echo "→ Dropped table if exists: " . ($m[1] ?? 'unknown') . "\n";
            }
        } catch (PDOException $e) {
            $errors++;
            echo "✗ Error: " . $e->getMessage() . "\n";
            echo "  Statement: " . substr($stmt, 0, 100) . "...\n\n";
        }
    }
    
    $pdo->exec("SET FOREIGN_KEY_CHECKS=1");
    
    echo "\n========================================\n";
    echo "DONE! Executed: $executed statements, Errors: $errors\n";
    echo "========================================\n\n";
    
    // Verify tables
    echo "Verifying tables:\n";
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        $count = $pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
        echo "  → $table: $count rows\n";
    }
    
    echo "\n✓ Database setup complete!\n";
    echo "⚠ IMPORTANT: DELETE this file (setup_db.php) after setup!\n";
    
} catch (PDOException $e) {
    echo "✗ Connection failed: " . $e->getMessage() . "\n";
}

echo "</pre>";
