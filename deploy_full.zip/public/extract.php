<?php
/**
 * Unzip deployment package on InfinityFree
 * Access via: http://arisanku.rf.gd/extract.php
 * DELETE THIS FILE AFTER USE!
 */

set_time_limit(300);
echo "<h2>Extracting deployment package...</h2><pre>";

$zipFile = __DIR__ . '/../deploy_full.zip';
if (!file_exists($zipFile)) {
    $zipFile = __DIR__ . '/deploy_full.zip';
}

if (!file_exists($zipFile)) {
    die("✗ deploy_full.zip not found! Upload it first via FTP.\n");
}

echo "✓ Found ZIP file: " . round(filesize($zipFile) / 1024 / 1024, 2) . " MB\n";

$zip = new ZipArchive();
$res = $zip->open($zipFile);

if ($res !== true) {
    die("✗ Failed to open ZIP file. Error code: $res\n");
}

echo "✓ ZIP contains " . $zip->numFiles . " files\n";
echo "Extracting to: " . dirname(__DIR__) . "\n\n";

// Extract to parent directory (htdocs root)
$extractPath = dirname(__DIR__);
if ($zip->extractTo($extractPath)) {
    echo "✓ Extraction complete!\n";
} else {
    echo "✗ Extraction failed!\n";
}

$zip->close();

// Copy .env.production to .env
$envProd = $extractPath . '/.env.production';
$envTarget = $extractPath . '/.env';

if (file_exists($envProd)) {
    copy($envProd, $envTarget);
    echo "✓ Copied .env.production → .env\n";
}

// Create storage directories if they don't exist
$storageDirs = [
    $extractPath . '/storage/app/public',
    $extractPath . '/storage/framework/cache',
    $extractPath . '/storage/framework/sessions',
    $extractPath . '/storage/framework/views',
    $extractPath . '/storage/logs',
];

foreach ($storageDirs as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
        echo "✓ Created: " . str_replace($extractPath, '', $dir) . "\n";
    }
}

// Create storage symlink
$publicStorage = $extractPath . '/public/storage';
$appPublic = $extractPath . '/storage/app/public';
if (!file_exists($publicStorage) && is_dir($appPublic)) {
    @symlink($appPublic, $publicStorage);
    echo "✓ Created storage symlink\n";
}

echo "\n========================================\n";
echo "EXTRACTION COMPLETE!\n";
echo "========================================\n";
echo "\nNext steps:\n";
echo "1. Visit http://arisanku.rf.gd/setup_db.php to import database\n";
echo "2. Visit http://arisanku.rf.gd/ to test the app\n";
echo "3. DELETE extract.php and setup_db.php!\n";
echo "</pre>";
